<?php 
	include_once('dbConnect.php');
	include_once('functions.php');

	if (!empty($_POST['btn-guess'])) {
	    guess();
        $_POST['btn-guess'] = null;
    } elseif (!empty($_POST['btn-accuse'])) {
        accuse();
        $_POST['btn-accuse'] = null;
    }
	
	function guess() {

	    if((!empty($_POST['txt-game-id'])) && !empty($_POST['sel-weapons']) && !empty($_POST['sel-players']) && !empty($_POST['txt-room'])) {
            $db = getDatabase();
            $gameID = $_POST['txt-game-id'];
            $selWeapons = $_POST['sel-weapons'];
            $selPerson = $_POST['sel-players'];
            $txtRoom = $_POST['txt-room'];

            $binds = array(
                ":gameID" => $gameID,
            );

            $sqlState = $db->prepare("SELECT * FROM schools " . $completeString);
            //$qry = 'SELECT * FROM cluecards WHERE GameID LIKE :gameID';
            $sqlState = $db->prepare($qry);

            if ($sqlState->execute($binds) && $sqlState->rowCount() > 0) {
                $results = $sqlState->fetchAll(PDO::FETCH_ASSOC);
            }
        }
        else
        {
            echo "NO POST";
        }
	}

	function accuse() {
        echo 'Accuse Function Executed Successfully';
    }
?>

<div class="col-12">
   <form method="post" action="guess-accuse.php">
	   <div class="row">
		   <div class="col-4">
			   <select id="sel-players" name="sel-players" class="btn btn-info btn-block btn-sm">
				   <option value="">Player:</option>
				   <option value="green">Green</option>
				   <option value="mustard">Mustard</option>
				   <option value="peacock">Peacock</option>
				   <option value="plum">Plum</option>
				   <option value="scarlet">Scarlet</option>
				   <option value="white">White</option>
			   </select>
		   </div>
		   <div class="col-4">
			   <select id="sel-weapons" name="sel-weapons" class="btn btn-info btn-block btn-sm">
				   <option value="">Weapon:</option>
				   <option value="candlestick">Candlestick</option>
				   <option value="dagger">Dagger</option>
				   <option value="leadPipe">Lead Pipe</option>
				   <option value="pistol">Pistol</option>
				   <option value="rope">Rope</option>
				   <option value="wrench">Wrench</option>
			   </select>
		   </div>
		   <div class="col-4">
			   <input type="text" id="txt-room" name="txt-room"
                      class="btn btn-secondary btn-block btn-sm" value="Ballroom" readonly>
           </div>
	   </div>
	   <div class="row">
		   <div class="col-6">
			   <input type="submit" id="btn-guess" name="btn-guess"
                      class="btn btn-primary btn-block btn-sm" value="Guess">
		   </div>
		   <div class="col-6">
			   <input type="submit" id="btn-accuse" name="btn-accuse"
                      class="btn btn-danger btn-block btn-sm" value="Accuse">
		   </div>
	   </div>
       <div class="row">
           <div class="col-6">
               <input type="text" id="txt-result" name="txt-result" Value="result" />
           </div>
           <div class="col-6">
               <input type="text" id="txt-game-id" Value="1" name="txt-game-id" />
           </div>
       </div>
   </form>
</div>
