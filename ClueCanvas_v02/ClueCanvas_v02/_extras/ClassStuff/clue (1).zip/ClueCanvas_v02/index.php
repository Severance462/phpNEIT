<?php

include_once('php/dice.php');
include_once('php/checklist.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Clue Web App">
    <meta name="author" content="Bryce Moore, Ryan Johns, John Lougee">

    <!-- boostrap.css -->
    <link rel="stylesheet"
          href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
          integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
          crossorigin="anonymous">

    <!-- Custom styles for this template -->
    <link rel="stylesheet" href="css/style.css" />

    <!-- Custom styles for this template -->
    <link rel="icon" type="img/png" href="favicon.png" />

    <title>NEIT | Clue</title>
</head>

<body>

<!-- navigation -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <a class="navbar-brand" href="index.php">
        <img src="favicon.png" width="30" height="30" class="d-inline-block align-top" alt="">
        NEIT
    </a>
</nav>

<!-- page content -->
<main class="container pt-5">
    <header class="row">
        <div class="col-lg-12">
            <h1 class="mt-4">Clue</h1>
            <p class="lead">by Bryce Moore, Justin Ferris, Angie Bustillo-Well and John Lougee</p>
            <hr>
        </div>
    </header>
    <section class="row" id="game-screen">
        <div class="col-6">
            <div class="row">
                <div class="col-12">
                    <canvas></canvas>
                </div>
            </div>
            <div id="dice" class="row">
                <div class="col-4">
                    <input type="text" id="die-a"
                           class="form-control form-control-sm text-center"
                    value="<?php echo $dice['a'] ?>">
                </div>
                <div class="col-4">
                    <input type="text" id="die-b"
                           class="form-control form-control-sm text-center"
                           value="<?php echo $dice['b'] ?>">
                </div>
                <div class="col-4">
                    <form method="post" action="index.php">
                        <button id="btn-roll" class="btn btn-block btn-sm btn-dark">
                            Roll
                        </button>
                        <input type="text" id="roll" name="roll" value="roll" hidden>
                    </form>
                </div>
            </div>
            <br>
            <br>
            <div id="selector" class="row">
                <div class="col-12">
                    <div class="row">
                        <div class="col-4">
                            <select id="sel-player" class="btn btn-info btn-block btn-sm" name="players">
                                <option value="0">Player:</option>
                                <option value="green">Green</option>
                                <option value="mustard">Mustard</option>
                                <option value="peacock">Peacock</option>
                                <option value="plum">Plum</option>
                                <option value="scarlet">Scarlet</option>
                                <option value="white">White</option>
                            </select>
                        </div>
                        <div class="col-4">
                            <select id="sel-weapon" class="btn btn-info btn-block btn-sm" name="weapons">
                                <option value="0">Weapon:</option>
                                <option value="candlestick">Candlestick</option>
                                <option value="dagger">Dagger</option>
                                <option value="leadPipe">Lead Pipe</option>
                                <option value="pistol">Pistol</option>
                                <option value="rope">Rope</option>
                                <option value="wrench">Wrench</option>
                            </select>
                        </div>
                        <div class="col-4">
                            <button type="button" id="btn-room" class="btn btn-secondary btn-block btn-sm"">
                                Room
                            </button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <button id="btn-guess" class="btn btn-primary btn-block btn-sm">Guess</button>
                        </div>
                        <div class="col-6">
                            <button id="btn-accuse" class="btn btn-danger btn-block btn-sm">Danger</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="row">
                <div class="col-12">
                    <table id="table-players"
                           class="table table-hover table-sm table-striped">
                        <thead>
                            <tr>
                                <th scope="col" id="th-ch">Character</th>
                                <th scope="col" id="th-p1">P1</th>
                                <th scope="col" id="th-p2">P2</th>
                                <th scope="col" id="th-p3">P3</th>
                                <th scope="col" id="th-p4">P4</th>
                                <th scope="col" id="th-p5">P5</th>
                                <th scope="col" id="th-p6">P6</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php echo getChecklist('players'); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <table id="table-weapons"
                           class="table table-hover table-sm table-striped">
                        <thead>
                        <tr>
                            <th scope="col" id="th-ch">Weapons</th>
                            <th scope="col" id="th-p1">P1</th>
                            <th scope="col" id="th-p2">P2</th>
                            <th scope="col" id="th-p3">P3</th>
                            <th scope="col" id="th-p4">P4</th>
                            <th scope="col" id="th-p5">P5</th>
                            <th scope="col" id="th-p6">P6</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php echo getChecklist('weapons'); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <table id="table-rooms"
                           class="table table-hover table-sm table-striped">
                        <thead>
                        <tr>
                            <th scope="col" id="th-ch">Rooms</th>
                            <th scope="col" id="th-p1">P1</th>
                            <th scope="col" id="th-p2">P2</th>
                            <th scope="col" id="th-p3">P3</th>
                            <th scope="col" id="th-p4">P4</th>
                            <th scope="col" id="th-p5">P5</th>
                            <th scope="col" id="th-p6">P6</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php echo getChecklist('rooms'); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>

</main><!-- /.container -->

<!-- jQuery-3.2.1.slim.min.js -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>

<!-- popper.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>

<!-- boostrap.js -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>

<!-- custom javascript -->
<script src="js/tile.js"></script>
<script src="js/board.js"></script>
<script src="js/index.js"></script>

</body>
</html>