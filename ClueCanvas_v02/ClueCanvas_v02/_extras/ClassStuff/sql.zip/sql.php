<?php

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

// This page holds all of the functions that work directly with mySQL

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

// Creates connection to the database.
function dbConn() {
    if (isset ($_SERVER['SERVER_NAME']) && $_SERVER['SERVER_NAME'] == 'ict.neit.edu') {
        $config = array(
            'DB_DNS' => 'mysql:host=localhost;port=5500;dbname=se266_bryce',
            'DB_USER' => 'se266_bryce',
            'DB_PASSWORD' => 'phprocks'
        );
    } else {
        $config = array(
            'DB_DNS' => 'mysql:host=localhost;port=3306;dbname=clue',
            'DB_USER' => 'root',
            'DB_PASSWORD' => ''
        );
    }
    try {
        $db = new PDO($config['DB_DNS'], $config['DB_USER'], $config['DB_PASSWORD']);
        $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }

    return $db;
}

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

// Returns data with results from query of the database table.
function runQuery($db, $query)
{
    try {
        $sql = $db->prepare($query);
        $sql->execute();
        return $sql;
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

// Performs action on the database table based on specified query.
// Parameters are bound using a for loop.
function runQueryBind($db, $qry, $fields, $values) {
    $count = count($fields);

    try {
        $sql = $db->prepare($qry);
        for ($i = 0; $i < $count; ++$i) {
            $sql->bindParam($fields[$i], $values[$i]);
        }
        $sql->execute();
    }
    catch (PDOException $e)
    {
        die("Error: " . $e->getMessage());
    }
}