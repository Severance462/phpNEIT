<?php

include_once('sql.php');
include_once('data.php');

function createCardTable() {
    $db = dbConn();

    insertCardTableRecord($db, $players, 'player');
    insertCardTableRecord($db, $weapons, 'weapon');
    insertCardTableRecord($db, $rooms, 'room');
}

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

// Inserts records into card table
function insertCardTableRecord($db, $data, $type) {
    $n = count($data);
    for($i = 0; $i < $n; ++$i) {
        $fields = array(':data', ':type');
        $values = array($data[$i], $type);
        $qry = 'INSERT INTO cards VALUES(null, :data, ';
        $qry .= ':type, 0)';
        runQueryBind($db, $qry, $fields, $values);
    }
}

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

// Inserts records into card table
function insertCardData($db, $gameId) {
    $fields = [
        ':playerId',
        ':gameId',
        ':ballroom',
        ':billiard_room',
        ':conservatory',
        ':dining_room',
        ':hall',
        ':kitchen',
        ':library',
        ':living_room',
        ':lounge',
        ':study',
        ':mr_green',
        ':colonel_mustard',
        ':mrs_peacock',
        ':professor_plum',
        ':miss_scarlet',
        ':mrs_white',
        ':candlestick',
        ':dagger',
        ':lead_pipe',
        ':pistol',
        ':rope',
        ':wrench'
    ];

    for ($y = 0; $y < 7; ++$y) {
        $n = count($fields);
        $values = array();
        $values[] = $y;
        $values[] = $gameId;
        for($x = 0; $x < $n - 3; ++$x) {
            $values[] = rand(1, 6);
        }

        $qry = 'INSERT INTO cluecards VALUES(null, :playerId, :gameId, ';
        $qry .= ' :ballroom, :billiard_room, :conservatory, :dining_room, ';
        $qry .= ':hall, :kitchen, :library, :living_room, :lounge, :study, ';
        $qry .= ':mr_green, :colonel_mustard, :mrs_peacock, :professor_plum, ';
        $qry .= ':miss_scarlet, :mrs_white, :candlestick, :dagger, :lead_pipe, ';
        $qry .= ':pistol, :rope, :wrench)';
        runQueryBind($db, $qry, $fields, $values);
    }
}